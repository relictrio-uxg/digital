<?php
/**
 * Relictrio Digital Contact us form
 *
 * @package Relictrio Digital
 */
?>


<div class="relictrio--contact--form">
      <form action="#" method="post">
        <fieldset>

          <label for="wnat" class="form_label">I want to*</label>
          <input type="text" id="want" name="want" placeholder="Select One">

          <label for="" class="form_label">Full Name*</label>
          <input type="text" id="mail" name="">

          <label for="" class="form_label">Company*</label>
          <input type="text" id="mail" name="">

          <label for="" class="form_label">Mobile number*</label>
          <input type="number" id="mail" name="">

          <label for="email" class="form_label">Email*</label>
          <input type="email" id="mail" name="email">
        
          <label for="" class="form_label">Website address:</label>
          <input type="text" id="" name="">
       
          <label for="password" class="form_label">Password:</label>
          <input type="password" id=""       name="">
        
    
          
        </fieldset>
        <fieldset>  
        

         <label for="bio">Bio:</label>
          <textarea id="bio" name="user_bio"></textarea>
        
       
        
         <label for="job">Job Role:</label>
          <select id="job" name="user_job">
            <optgroup label="Web">
              <option value="frontend_developer">Front-End Developer</option>
              <option value="php_developer">PHP Developer</option>
              <option value="python_developer">Python Developer</option>
              <option value="rails_developer">Rails Developer</option>
              <option value="web_designer">Web Designer</option>
              <option value="wordpress_developer">Wordpress Developer</option>
            </optgroup>
            <optgroup label="Mobile">
              <option value="android_developer">Android Developer</option>
              <option value="ios_developer">IOS Developer</option>
              <option value="mobile_designer">Mobile Designer</option>
            </optgroup>
            <optgroup label="Business">
              <option value="business_owner">Business Owner</option>
              <option value="freelancer">Freelancer</option>
            </optgroup>
          </select>
          
         
         </fieldset>
       
        <button type="submit">Sign Up</button>
        
       </form>
      </div>
      