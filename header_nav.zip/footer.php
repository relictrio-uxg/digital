<!-- <footer>
        <div class="footer__wrapper">
            <div class="footer__logoContainer">
                <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/relictrio_logo.png" alt="relictrio digital's logo">
            </div>
            <div class="footer__menusContainer">
                <div class="footer__menusCall">
                    <div class="footer__menuHeading">
                        Call to hear our soothing voice
                    </div>
                    <div class="footer__menuNumber">
                        <div class="footer__menuIconContainer">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_telephone.png" alt="telephone icon">
                        </div>
                        <div class="footer__menuContactNumber">
                            +91-6363049704
                        </div>
                    </div>
                </div>
                <div class="footer__menusEmail">
                    <div class="footer__menuHeading">
                        We quickly reply to mails
                    </div>
                    <div class="footer__menuEmailId">
                        <div class="footer__menuIconContainer">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_at.png" alt="email at icon">
                        </div>
                        <div class="footer__menuMailId">
                            contact@relictrio.com
                        </div>
                    </div>
                </div>
                <div class="footer__menusAddress">
                    <div class="footer__menuHeading">
                        Contact
                    </div>
                    <div class="footer__menuLocation">
                        <div class="footer__menuIconContainer">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_at.png" alt="email at icon">
                        </div>
                        <div class="footer__menuMailId">
                            Horamavu Main Road, Bengaluru, Karnataka, India - 560043
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footerFooterContainer">
            <div class="footerFooterWrapper">
                <div class="footerFooter__copyright">
                    Copyright @ relictrio digital 2015-2021
                </div>
                <div class="footerFooter__iconContainer">
                    <div class="footerFooter__socialIcon">
                        <a href="">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_twitter.png" alt="twitter icon">
                        </a>
                    </div>
                    <div class="footerFooter__socialIcon">
                        <a href="">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_fb.png" alt="facebook icon">
                        </a>
                    </div>
                    <div class="footerFooter__socialIcon">
                        <a href="">
                            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/icon_insta.png" alt="instagram icon">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </footer> -->



    </body>
</html>